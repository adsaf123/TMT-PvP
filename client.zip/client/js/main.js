const SERVERINFO = {
    SERVERIP: "https://TMTPVPServer.adsaf.repl.co",
    PLAYERSETNICK: "playerSetNick",
    PLAYERJOINGAME: "playerJoinGame",
    PLAYERHOSTGAME: "playerHostGame",
    HOSTKICKPLAYER: "hostKickPlayer",
    PLAYERGETGAMEINFO: "playerGetGameInfo"
}

var gamesList = {}
var currentGame = -1
var currentGameData = {}

function lateAddLayer(layerName, layerData) { // Call this to add layers from a different file!
    layersNeededToLoad.push([layerName, layerData])
}

addLayer("main-menu", {
    startData() {
        return {
            unlocked: true,
            points: new Decimal(0),
            nick: "example"
        }
    },

    type: "none",
    row: "none",

    tabFormat: [
        ["display-text", "Set your username"],
        ["text-input", "nick"],
        ["clickable", "confirm-nick"]
    ],

    clickables: {
        "confirm-nick": {
            display() { return "Confirm" },
            canClick() { return true },
            onClick() { sendNickToServer(); showNavTab("games-list") }
        }
    }
})

addLayer("games-list", {
    startData() {
        return {
            unlocked: true,
            points: new Decimal(0)
        }
    },

    row: "none",
    type: "none",

    tabFormat: [
        ["display-text", "Games list:"],
        "blank",
        generateGamesList,
        "blank",
        ["buyable", "createServer"]
    ],

    clickables: generateGamesClickables,

    buyables: {
        "createServer": {
            cost() { return new Decimal(0) },
            canAfford() { return true },
            display() { return "Host your own game" },
            buy() { showNavTab("host-game") }
        }
    },

    update(diff) {
        if (player.navTab == "games-list")
            getGamesFromServer()
    }
})

addLayer("host-game", {
    startData() {
        return {
            unlocked: true,
            points: new Decimal(0),
            maxPlayers: 0,
            selectedTree: ""
        }
    },

    row: "none",
    type: "none",

    tabFormat: [
        ["display-text", "Host your game"],
        "blank",
        ["clickable", "TPT"],
        "blank",
        ["display-text", "Number of players:"],
        ["text-input", "maxPlayers"],
        "blank",
        ["clickable", "host"]
    ],

    clickables: {
        "TPT": {
            display() { return "The Prestige Tree" },
            canClick() { return player[this.layer].selectedTree != "TPT" },
            onClick() { player[this.layer].selectedTree = "TPT" }
        },

        "host": {
            display() { return "Host Game" },
            canClick() { return player[this.layer].selectedTree != "" },
            onClick() { hostGame(); showNavTab("game-lobby") }
        }
    }
})

addLayer("game-lobby", {
    startData() {
        return {
            unlocked: true,
            points: new Decimal(0)
        }
    },

    row: "none",
    type: "none",

    tabFormat: [
        ["display-text", "Lobby"],
        "blank",
        function () {
            if (currentGameData.id == -1) return [["display-text", "waiting for data from server"]]
            if (currentGameData.id == -2) return [["display-text", "you've been kicked"], ["clickable", "return"]]
            var list = ["row", [
                ["column", []],
                "blank",
                ["column", []],
                "blank",
                ["column", []],
            ]]
            
            if (currentGameData.players == undefined) return [["display-text", "something's wrong"]]

            for (const player of currentGameData.players) {
                list[1][0][1].push(["display-text", player.nick])
                list[1][2][1].push(["display-text", player.ip == currentGameData.host ? "HOST" : ""])
                list[1][4][1].push(["clickable", `kp${player}`])
            }
        
            return list
        }
    ],

    clickables: generateKickClickables,

    update(diff) {
        if (player.navTab == "game-lobby")
            getGameData()
    }

})

var getGameData = function () {
    fetch(`${SERVERINFO.SERVERIP}/gameInfo`).then(function (response) {
        response.json().then(function (data) {
            currentGameData = data
        })
    })
} 

var hostGame = function () {
    fetch(SERVERINFO.SERVERIP, {
        method: "POST",
        headers: {
            "Accept": "application/json",
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            type: SERVERINFO.PLAYERHOSTGAME,
            tree: player["host-game"].selectedTree,
            maxPlayers: player["host-game"].maxPlayers
        })
    })
}

var getGamesFromServer = function () {
    fetch(`${SERVERINFO.SERVERIP}/games`).then(function (response) {
        response.json().then(function (data) {
            gamesList = data
        })
    })
}

var sendDataToServer = function (data) {
    fetch(SERVERINFO.SERVERIP, {
        method: "POST",
        headers: {
            "Accept": "application/json",
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    })
}

var sendNickToServer = function () {
    sendDataToServer({
        type: SERVERINFO.PLAYERSETNICK,
        nick: player["main-menu"].nick
    })
}

var generateGamesList = function () {
    var list = ["row", [
        ["column", []],
        "blank",
        ["column", []],
        "blank",
        ["column", []],
        "blank"
        ["column", []]
    ]]
    for (const [k, v] of Object.entries(gamesList)) {
        list[1][0][1].push(["display-text", v.host])
        list[1][2][1].push(["display-text", v.tree])
        list[1][4][1].push(["display-text", `${v.players.length}/${v.maxPlayers}`])
        list[1][6][1].push(["clickable", `jg${k}`])
    }
}

var generateGamesClickables = function () {
    var clickables = {}
    for (const [k, v] of Object.entries(gamesList)) {
        clickables[`jg${k}`] = {}
        clickables[`jg${k}`].display = function () { return "join" }
        clickables[`jg${k}`].canClick = function () { return true }
        clickables[`jg${k}`].onClick = function () { joinGame(k); showNavTab("game-lobby") }
        clickables[`jg${k}`].style = { "width": "30px", "height": "30px" }
    }
    return clickables
}

var generateKickClickables = function () {
    var clickables = {}
    for (const [k, v] of Object.entries(gamesList)) {
        clickables[`kp${k}`] = {}
        clickables[`kp${k}`].display = function () { return "kick" }
        clickables[`kp${k}`].canClick = function () { return true }
        clickables[`kp${k}`].onClick = function () { sendDataToServer({ type: SERVERINFO.HOSTKICKPLAYER, playerID: currentGameData.players[k] }) }
        clickables[`kp${k}`].style = { "width": "30px", "height": "30px" }
    }
    clickables["return"] = {
        display() { return "return to menu" },
        canClick() { return true },
        onClick() { showNavTab("games-list") }
    }
    return clickables
}

var joinGame = function (gameID) {
    sendDataToServer({
        type: SERVERINFO.PLAYERJOINGAME,
        gameID: gameID
    })
}